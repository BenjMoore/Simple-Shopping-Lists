﻿using DataMapper;
using ICTPRG535_556.Controllers;
using ICTPRG535_556.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

public class CartController : BaseController
{
    private readonly DataAccess _dataAccess;

    public CartController()
    {
        _dataAccess = new DataAccess();
    }

    public int selectedList = 0;



    [Route("/Cart")]
    public IActionResult UserCart(int id)
    {
        if (LoggedInUserId.HasValue)
        {
            // Retrieve list IDs for the user
            var listIDs = _dataAccess.GetUserLists(id);

            // Get the first list ID
            int? firstListId = listIDs.FirstOrDefault();

            if (firstListId != null)
            {
                // Retrieve list items for the first list
                List<ListDTO> listItems = _dataAccess.GetListItems(firstListId.Value);
                List<ProduceDTO> cartItems = new List<ProduceDTO>();

                // Iterate through each list item
                foreach (var listItem in listItems)
                {
                    // Retrieve products for the current list item
                    var userProducts = _dataAccess.GetUserListProducts(listItem.ItemID);

                    // Iterate through the products and fetch details for each item
                    foreach (var product in userProducts)
                    {
                        // Create a new cart item and add it to the list
                        var cartItem = new ProduceDTO
                        {
                            ItemID = product.ItemID,
                            Name = _dataAccess.GetProductName(product.ItemID),
                            Price = _dataAccess.GetProductPriceByItemId(product.ItemID),
                            Unit = _dataAccess.GetProductWeight(product.ItemID)
                        };

                        cartItems.Add(cartItem);
                    }
                }

                // Pass cart items to the view
                return View(cartItems);
            }
            else
            {
                // Handle the case where the user has no lists
                return View("NoLists");
            }
        }
        else
        {
            // User is not logged in, redirect to login page or handle as needed
            return RedirectToAction("Login", "Auth");
        }
    }
    public IActionResult CreateNewList(int listID)
    {
        var loggedInUserId = HttpContext.Session.GetInt32("UserId") ?? 0;
        var maxlistid = _dataAccess.GetMaxListIdForUser(Convert.ToInt32(loggedInUserId));
        int newListID = Convert.ToInt32(maxlistid) + 1;
        var newList = new ListDTO
        {
            UserID = loggedInUserId,
            ListID = newListID,
            ItemID = 0
        };
        _dataAccess.AddList(newList);
        return RedirectToAction("SelectList", "Cart");
    }
    public IActionResult Select()
    {
        // Check if the logged-in user ID is available in the session
        if (HttpContext.Session.GetInt32("UserId").HasValue)
        {
            // Retrieve the logged-in user ID from the session
            int loggedInUserId = HttpContext.Session.GetInt32("UserId").Value;

            // Retrieve all lists for the logged-in user
            var userLists = _dataAccess.GetAllUserLists(loggedInUserId);

            return View(userLists);
        }
        else
        {
            return RedirectToAction("Login", "Auth");
        }
    }

    public IActionResult SelectList(int listId)
    {
        // Check if the user is logged in
        if (HttpContext.Session.GetInt32("UserId").HasValue)
        {
            // Save the selected list ID in the session
            HttpContext.Session.SetInt32("ListId", listId);

            var list = _dataAccess.GetListById(listId);
            if (list == null)
            {
                // Handle the case where the list is not found
                return RedirectToAction("UserCart", "Cart"); // Redirect to a suitable page
            }

            List<ListDTO> listItems = _dataAccess.GetListItems(listId);
            List<SessionCartDTO> cartItems = new List<SessionCartDTO>();

            // Get produce information for each item in the list
            foreach (var listItem in listItems)
            {
                // Retrieve products for the current list item
                var userProducts = _dataAccess.GetUserListProducts(listItem.ItemID);

                // Iterate through the products and fetch details for each item
                foreach (var product in userProducts)
                {
                    int? nullableQuantity = _dataAccess.GetItemQuantityInList(listId, product.ItemID);
                    int quantity = nullableQuantity ?? 1;

                    // Create a new cart item and add it to the list
                    var cartItem = new SessionCartDTO
                    {
                        ItemID = product.ItemID,
                        Name = _dataAccess.GetProductName(product.ItemID),
                        Price = Convert.ToString(_dataAccess.GetProductPriceByItemId(product.ItemID)),
                        Unit = _dataAccess.GetProductWeight(product.ItemID),
                        ListID = listId,
                        Quantity = quantity

                    };

                    cartItems.Add(cartItem);
                }
                // Null check before setting ListName in session
                if (!string.IsNullOrEmpty(listItem.ListName))
                {
                    HttpContext.Session.SetString("ListName", listItem.ListName);
                }
            }

            // Calculate total price for the current list
            decimal totalPrice = CalculateTotalPrice(cartItems);

            // Pass cart items and total price to the view
            ViewBag.TotalPrice = totalPrice;
            return View(cartItems);
        }
        else
        {
            // User is not logged in, redirect to the login page
            return RedirectToAction("Login", "Auth");
        }
    }

    private decimal CalculateTotalPrice(List<SessionCartDTO> items)
    {
        decimal totalPrice = 0;
        foreach (var item in items)
        {
            // Assuming Price is stored as decimal in SessionCartDTO
            totalPrice += Convert.ToDecimal(item.Price);
        }
        return totalPrice;
    }


    [HttpPost]
    public IActionResult UpdateListName(int listId, string newListName)
    {
        try
        {
            _dataAccess.UpdateListName(listId, newListName);
            return Json(new { success = true });
        }
        catch (Exception ex)
        {
            return StatusCode(500, ex.Message);
        }
    }

    [HttpPost]
    public IActionResult UpdateQuantity(int itemId, int listId, int quantityChange)
    {
        int userId = Convert.ToInt32(HttpContext.Session.GetInt32("UserId"));
        try
        {
            int currentQuantity = _dataAccess.GetItemQuantityInList(listId, itemId);
            int newQuantity = currentQuantity + quantityChange;

            if (newQuantity == 0)
            {
                _dataAccess.DeleteProduce(listId, itemId, userId);
                return Json(new { success = true, newQuantity = 0, newPrice = 0, totalPrice = GetTotalPrice(listId) });
            }
            else
            {
                _dataAccess.UpdateItemQuantity(listId, itemId, quantityChange);
                _dataAccess.UpdateCartPrice(listId, itemId, newQuantity);

                decimal newPrice = _dataAccess.GetProductPriceByItemId(itemId) * newQuantity;
                decimal totalPrice = GetTotalPrice(listId);

                return Json(new { success = true, newQuantity = newQuantity, newPrice = newPrice.ToString("F2"), totalPrice = totalPrice.ToString("F2") });
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, ex.Message);
        }
    }


    public decimal GetTotalPrice(int listId)
    {
        try
        {
            AuthController authController = new AuthController();

            int userId = authController.GetUserId();

            var listProducts = _dataAccess.GetListItems(listId);
            decimal totalPrice = 0;

            foreach (var item in listProducts)
            {
                decimal price = _dataAccess.GetProductPriceByItemId(item.ItemID);
                totalPrice = price * item.Quantity;
            }
            return totalPrice;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        return 0;
    }


    [HttpPost]
    [Route("logout")]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Index", "Home");
    }
    [HttpPost]
    public IActionResult DeleteList(int listId)
    {
        // Add logic to delete the list with the specified ID
        _dataAccess.DeleteList(listId);
        return RedirectToAction(nameof(SelectList), new { listId }); // Redirect to the same action with the listId
    }

    [HttpPost]
    public IActionResult DeleteProduce(int itemId, int userId)
    {
        int listId = 0;
        HttpContext.Session.SetInt32("ListId", listId);
        try
        {
            // Call the DeleteProduce method in your data access layer
            _dataAccess.DeleteProduce(itemId, userId, listId);

            // Return a success response for AJAX
            return Ok();
        }
        catch (Exception ex)
        {
            // Return an error response for AJAX
            return StatusCode(500, ex.Message);
        }
    }



}



﻿using Microsoft.AspNetCore.Mvc;

namespace ICTPRG535_556.Controllers
{
    public class SettingsController : BaseController
    {
        [Route("Settings")]
        public IActionResult Settings()
        {
            return View();
        }
    }
}

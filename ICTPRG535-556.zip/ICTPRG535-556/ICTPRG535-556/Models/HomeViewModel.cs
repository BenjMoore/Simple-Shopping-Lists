﻿using System.Collections;

namespace ICTPRG535_556.Models
{
    public class HomeViewModel
    {
        public ArrayList ProduceItems { get; set; }
    }

}

﻿namespace ICTPRG535_556.Models
{
    public class CartIdentifier
    {
        public int ItemID { get; set; }
        public string ProductName { get; set; }
        public string ProductPrice { get; set; }
        public string ProductWeight { get; set; }
        // Add more properties as needed

        // Constructor

    }
}


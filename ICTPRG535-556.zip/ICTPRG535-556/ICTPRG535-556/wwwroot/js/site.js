﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.
// JavaScript function to toggle color mode and store preference

// Apply stored color mode on page load
document.addEventListener("DOMContentLoaded", function () {
    var storedColorMode = sessionStorage.getItem("colorMode");
    if (storedColorMode === "dark") {
        document.body.classList.add("dark-mode"); // Apply dark mode class if preference is stored
    }
});
// Write your JavaScript code.

using DataMapper;
using ICTPRG535_556.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace ICTPRG535_556
{
    public class Startup
    {
        public static void Main(string[] args)
        {
            DataAccess con = new DataAccess();
            Console.Out.WriteLine(con.GetLists());
            CreateHostBuilder(args).Build().Run();
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSession(opts =>
            {
                opts.IdleTimeout = TimeSpan.FromMinutes(3);
                opts.Cookie.HttpOnly = true;
                opts.Cookie.IsEssential = true;
            });
            services.AddControllersWithViews();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });



        public void Configure(IApplicationBuilder app, IHostEnvironment env)
        {
            if (!env.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios.
                // See https://aka.ms/aspnetcore-hsts
                app.UseHsts();
            }
            // Define the session parameters

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            app.UseSession();
            app.UseAuthorization();
            app.UseDeveloperExceptionPage();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");

                endpoints.MapControllerRoute(
                name: "produceSearch",
                pattern: "Produce/Search",
                defaults: new { controller = "Produce", action = "Search" }
);



            });


        }
    }
}
